//
//  ImaginariumViewController.h
//  Imaginarium
//
//  Created by CS193p Instructor.
//  Copyright (c) 2011 Stanford University. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ImaginariumViewController : UIViewController

@end
