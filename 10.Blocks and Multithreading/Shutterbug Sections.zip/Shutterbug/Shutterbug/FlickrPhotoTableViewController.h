//
//  FlickrPhotoTableViewController.h
//  Shutterbug
//
//  Created by CS193p Instructor.
//  Copyright (c) 2011 Stanford University. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FlickrPhotoTableViewController : UITableViewController
@property (nonatomic, strong) NSArray *photos; // of Flickr photo dictionaries
@end
