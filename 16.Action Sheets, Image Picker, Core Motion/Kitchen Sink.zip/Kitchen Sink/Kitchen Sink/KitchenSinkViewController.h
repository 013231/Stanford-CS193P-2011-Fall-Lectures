//
//  KitchenSinkViewController.h
//  Kitchen Sink
//
//  Created by CS193p Instructor.
//  Copyright (c) 2011 Stanford University. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KitchenSinkViewController : UIViewController

@end
